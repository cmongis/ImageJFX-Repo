var plan = require('flightplan');

var appName = 'update_server';
var username = 'ijfx';
var startFile = 'server.js';

var tmpDir = appName + '-' + new Date().getTime();
var remoteTmp = '/tmp/' + tmpDir;
var versionsDir = '~/' + appName + '/' + tmpDir;
var currentDir = '~/' + appName + '/current';
plan.target('production', [
  {
    host: 'imagejfx.net',
    username: username,
    agent: process.env.SSH_AUTH_SOCK
  }
//add in another server if you have more than one
// {
//   host: '104.131.93.216',
//   username: username,
//   agent: process.env.SSH_AUTH_SOCK
// }
]);

// run commands on localhost
plan.local(function(local) {
  // uncomment these if you need to run a build on your machine first
  // local.log('Run build');
  // local.exec('gulp build');

  local.log('Copy files to remote hosts');
  var filesToCopy = local.exec("find -L . -not -path './node_modules/*' -not -name 'private_rsa*' -not -name '.*' -not -path './usage*'", {silent: false});
  // rsync files to all the destination's hosts
  local.transfer(filesToCopy, remoteTmp);
});

// run commands on remote hosts (destinations)
plan.remote(function(remote) {
  remote.log('Move folder to root '+remoteTmp);
  remote.exec('cp -R ' + remoteTmp + ' ' + versionsDir, {user: username});
	remote.log('Deleting '+remoteTmp);
  remote.rm('-rfv '+remoteTmp);

  remote.log('Install dependencies');
  remote.exec('npm --production --prefix ' + versionsDir + ' install ' + versionsDir, {user: username});

  remote.log('Reload application');
  remote.exec('ln -snf ' + versionsDir + ' '+ currentDir, {user: username});
  remote.exec('forever stop ' + currentDir + '/' +startFile, {failsafe: true});
  remote.exec('forever start ' + currentDir + '/' +startFile + ' --expose-gc');
});