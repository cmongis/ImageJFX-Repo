/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var config = require("./config.js");

var fs = require("fs");

var util = require("util");
var UPDATE_ROOM = "subscribe/update";
var USER_ROOM = "user";
var USER_WATCHER = "subscribe/user_number";

var USER_NUMBER_EVENT = "user number changed";
var USAGE_EVENT = "usage";


function getClientNumber(io, room) {

    var room = io.sockets.adapter.rooms[room];
    return    Object.keys(room).length;

}


function ReportHandler(usage) {
    var usageFile = config.usageFolder + usage.session_id;
    var sessionId = usage.session_id;
    
    if(sessionId.indexOf("/") > -1 || sessionId.indexOf(".") > -1) return;
    
    delete usage["session_id"];
    fs.appendFile(usageFile,JSON.stringify(usage)+"\n",function(err,data) {
        if(err) {
            console.log("Error when appending file",err);
        }
    });
    fs.appendFile(usageFile+".hr",util.format("%d:[%s] - %s - %s (value = %s)\n",usage.position,usage.location,new String(usage.type).toUpperCase(),usage.name,usage.value));
    console.log("Writing usage in ",usageFile);
}

module.exports = function (io_server) {

    io_server.set('heartbeat interval', config.heartbeatInterval);

    // push server
    io_server.on("connection", function (socket) {


        // subscribes to the update channel
        socket.on(UPDATE_ROOM, function () {
            console.log("new subcribtion !", socket.handshake.address);
            // when a socket is open, we push the socket into the list
            //open_sockets.push(socket);
            // console.log("We have now " + open_sockets.length + " connected users");
            console.log("")
            socket.join(UPDATE_ROOM);
            console.log("User joined ", UPDATE_ROOM, socket.handshake.address);
            socket.emit("welcome");

          
            // broadcast to the number of people actually using the software
            io_server
                    .to(USER_WATCHER)
                    .emit(USER_NUMBER_EVENT, getClientNumber(io_server,UPDATE_ROOM));

        });
        
        
        socket.on("get/user_number",function() {
            console.log("get/user_number request received ")
            socket.emit("user number changed",getClientNumber(io_server,UPDATE_ROOM));
        });

        socket.on(USER_WATCHER, function () {
            console.log("User joined ", USER_WATCHER, socket.handshake.address);
            socket.join(USER_WATCHER);
        });



        // when the socket ends, it's took out from the list
        socket.on('disconnect', function () {
            console.log("someone is gone");
            //var i = open_sockets.indexOf(socket);
            //open_sockets.splice(i, 1);

        });



        socket.on(USAGE_EVENT, function (data) {
            console.log("Received usage data");
            console.log(data);
            ReportHandler(data);
            
        });


        socket.on('error', function (error) {
            console.log("we lost some one...", error);
        });
        ;
    });

    io_server.on("disconnect", function (socket) {
        console.log("we lost someone !");
    });

}
;