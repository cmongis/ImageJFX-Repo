var fs = require("fs");
var exec = require('child_process').exec;
var Seq = require("seq");
var config = require("./config.js")
var ref;
var client;
var checker = require("./checker.js");
var watch = require("node-watch");
var jsonfile = require("jsonfile");
var express = require("express");
var io = require("socket.io");
var http = require("http");
var bodyParser = require('body-parser');
var exec = require("child_process").exec
var distributionFile = __dirname+"/distribution.json";
console.log(distributionFile);
var Builder = require("./builder.js");
var app = express();
app.use(bodyParser.json());
var server = http.Server(app);
var io_server = io(server);

// apply the handlers to the io_server
require("./io_server.js")(io_server);

// user connected to the server
var open_sockets = [];



var triggerFile = ".do_update";

var builder = new Builder("/home/ijfx/build/","bash newbuild.sh");

function updateDistribution(callback) {
	checker.check(config.distribution,function(err,dist) {
			jsonfile.writeFile(distributionFile,dist,callback);
	});
}










// serving the static server
app.use('/files', express.static(config.distribution));

app.post("/check",function(req,res) {
	
	Seq()
		.seq(function() {
			jsonfile.readFile(distributionFile,this);
		})
		.seq(function(referenceDistribution) {
			var client = req.body;
			console.log(req.body);
			var toDo = checker.compare(referenceDistribution,client);
			res.status(200).json(toDo);
		});
});

app.get("/",function(req,res) {
	
	Seq()
		.seq(function() {
		jsonfile.readFile(distributionFile,this);
	})
	.seq(function(dist) {
		res
			.status(200)
			.json(dist);
	})
});
app.get("/recreate",function(req,res) {
	
	updateDistribution(function(err) {
		
		if(err != null) {
			res.status(200).json(err);
		}
		else {
			res.status(200).send("Succes !");
		}
	})
});



/*
app.post("/build/:action",function(req,res) {
	var action = req.params.action;
	if(action == "start") {
		builder.start();
		res.status(200)
			//.set('Content-Type', 'text/pain')
			.send(builder.getStatus());
	}
	else if(action == "status") {
		res.status(200)
		//.set('Content-Type', 'text/pain')
		.send(builder.getStatus());
	}
	else if(action == "out") {
		res.status(200)
		//thuthun.set('Content-Type', 'text/pain')
		.send(builder.getLastRun());
	}
	else {
		res.send("Action unknown");
	}
});*/






// Watching the file system
var toWatch = config.distribution;
if(toWatch[toWatch.length -1] != "/") {
	toWatch = toWatch + "/";
}
console.log("Watching "+toWatch);
// watching the update trigger file which calculates the distribution
watch(config.distribution,function(filename) {
	console.log("file changed "+filename);
	if(filename.indexOf(triggerFile) >= 0 && filename.length == triggerFile.length) {
		console.log("updating distribution")
		updateDistribution();
                
                io_server
                        .to(UPDATE_ROOM)
                        .emit("new update");
                
                /**
		open_sockets.forEach(function (socket) {
			socket.emit("new update");
		});*/
	}
});

console.log("Listening on ",config.port);
server.listen(config.port);



//checkFolder("/Users/cyril/Code/imagejfx/target/ijfx-1.0-SNAPSHOT-bin/ijfx-1.0-SNAPSHOT/")
