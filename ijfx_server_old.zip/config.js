module.exports = {
	//repository:"/home/ijfx/updates/",
	//repository:"/home/cyril/Code/ijfx-repo/dist/"
	distribution:"/home/ijfx/dist/"
	//distribution:"/Users/cyril/Code/imagejfx/target/ijfx-1.0-SNAPSHOT-bin/ijfx-1.0-SNAPSHOT"
	,port:8008
	,heartbeatInterval:5000
	,host:"http://update.imagejfx.net/"
        ,usageFolder:"/home/ijfx/usage/"
}