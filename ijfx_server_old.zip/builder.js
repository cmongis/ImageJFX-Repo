var exec = require("child_process").exec;

module.exports = function (dir, command) {

	var self = this;

	self.isStarted = false;
	self.dir = dir;
	self.command =command;
	self.currentProcess;
	self.lastRun = "None";
	self.start = function () {
		// if there is no process started
		if (self.isStarted == false) {
			
			// starting the process
			self.currentProcess = exec(
				self.command, {
					"cwd": self.dir
				},
				function (err, stdout, stderr) {
					self.lastRun =  stdout + "\n\nError:\n\n"
					+err+"\n\n" +
					stderr;
					// on finished, we put back the variable
					self.isStarted = false;
				}
			);
			// after starting, we put it true
			self.isStarted = true;
		}
	}
	self.getLastRun = function() { return self.lastRun };

	
	self.getStatus  = function() {
		return self.isStarted ? "Running" : "Waiting";
	}
}