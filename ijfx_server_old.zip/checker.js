var config = require("./config.js");
var Seq = require("seq");
var fs = require("fs");
var exec = require('child_process').exec;
var spawnSync = require('spawn-sync');

var md5sum = function (path) {

	if(fs.existsSync(path+".md5")) {
		console.log("MD5 is already calculated");
		return fs.readFileSync(path+".md5","utf8").trim().split(" ")[0];
	}
	
	var md5;
	try {
		md5 = spawnSync('md5sum', [path]).stdout.toString();
	} catch (e) {
		md5 = spawnSync('md5', ['-r', path]).stdout.toString();
	}
	return md5.split(" ")[0];
}

var getExtension = function(fileName) {
	var ext = fileName.substr(fileName.lastIndexOf('.') + 1);
	return ext;
}

var checkExtension = function(fileName,extension) {
	return getExtension(fileName) == extension;
}


module.exports = {
	check: function (folder, callback) {

		Seq()
			.seq(function () {
				if (folder[folder.length - 1] != "/") folder = folder + "/";
				exec("find " + folder.replace(/ /g, "\\ "), this);
			})
			.seq(function (output) {

				var result = {};

				output = output.split("\n")
					.map(function (i) {
						return i.substring(folder.length);
					})
					.filter(function (f) {
						return f != "" &&
							f.indexOf(".") != -1 && f.length > 2 && f.indexOf("." != 0) && f != ".update_trigger"
					})
					.filter(function(f) {
						return !checkExtension(f,"md5");
					})
					.map(function (file) {
						var stats = undefined;
						try {
							stats = fs.statSync(folder + file);
						} catch (e) {
							console.log(e);
						}

						return {
							absolutePath: folder + file,
							subPath: file,
							stats: stats
						}
					})
					
					.filter(function (file) {

						return file.stats != undefined && file.subPath.indexOf("/.") == -1 && file.subPath.indexOf("/_") == -1;
					})
					.forEach(function (file) {

						if (file.subPath != "") {
							console.log("MD5 summing " + file.subPath + "...");
							try {
								result[file.subPath] = md5sum(file.absolutePath);
								console.log("[OK]");
							} catch (e) {
								console.log(e);
								console.log("[FAILED] trying again for " + file.subPath);
								result[file.subPath] = md5sum(file.absolutePath);
							}
						}

					});
				callback(null, result);
			});
	},
	compare: function (reference, client) {

		console.log("comparing");

		var toAdd = [];
		var toDelete = [];
		for (f in reference) {
			if (client[f] == undefined || client[f] != reference[f]) {
				toAdd.push(f);
			}
		}
		for (f in client) {
			if (reference[f] == undefined) {
				toDelete.push(f);
			}
		}

		return {
			add: toAdd,
			delete: toDelete,
			filesAddress: "files/"
		};
	}
};